const MESSAGE_NAMESPACE = "opencut-cursor";

const elements = {
	captureTab: document.getElementById("capture-tab"),
	start: document.getElementById("start"),
	stop: document.getElementById("stop"),
	export: document.getElementById("export"),
	status: document.getElementById("status"),
};

function setStatus(message, isError = false) {
	elements.status.textContent = message;
	elements.status.dataset.error = String(isError);
}

async function getActiveTab() {
	const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
	if (!tab?.id) {
		throw new Error("No active tab found");
	}
	return tab;
}

async function sendRuntimeMessage(type, payload) {
	return await chrome.runtime.sendMessage({
		namespace: MESSAGE_NAMESPACE,
		type,
		payload,
	});
}

async function sendMessage(type) {
	const tab = await getActiveTab();
	return await chrome.tabs.sendMessage(tab.id, {
		namespace: MESSAGE_NAMESPACE,
		type,
	});
}

function buildFilename(title) {
	const safeTitle = (title || "tracking")
		.toLowerCase()
		.replace(/[^a-z0-9]+/g, "-")
		.replace(/^-+|-+$/g, "")
		.slice(0, 40);
	const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
	return `${safeTitle || "tracking"}-${timestamp}.opencut-cursor.json`;
}

async function getPendingCaptureRequest() {
	const tab = await getActiveTab();
	const response = await sendRuntimeMessage("tab-capture-get-pending", {
		windowId: tab.windowId,
	});
	if (!response?.ok) {
		throw new Error(response?.error || "OpenCut capture request is unavailable");
	}
	return response.payload ?? null;
}

async function refreshStatus() {
	try {
		const activeTab = await getActiveTab();
		const pendingCapture = await getPendingCaptureRequest().catch(() => null);
		elements.captureTab.disabled =
			!pendingCapture || pendingCapture.controllerTabId === activeTab.id;

		const response = await sendMessage("status");
		if (!response?.ok) {
			throw new Error(response?.error || "Tracking status is unavailable");
		}

		elements.start.disabled = response.tracking;
		elements.stop.disabled = !response.tracking;
		elements.export.disabled = Boolean(response.tracking);

		setStatus(
			pendingCapture
				? pendingCapture.controllerTabId === activeTab.id
					? "Switch to the tab you want to capture, then click Capture this tab."
					: "OpenCut is waiting. Click Capture this tab to send this tab to OpenCut."
				: response.tracking
					? `Tracking in progress. ${response.eventCount} events recorded.`
					: `${response.eventCount} events ready to export.`,
		);
	} catch (error) {
		elements.captureTab.disabled = true;
		elements.start.disabled = false;
		elements.stop.disabled = true;
		elements.export.disabled = true;
		setStatus(
			error instanceof Error
				? error.message
				: "This page cannot be tracked from the extension.",
			true,
		);
	}
}

async function captureTabForOpenCut() {
	try {
		const activeTab = await getActiveTab();
		const pendingCapture = await getPendingCaptureRequest();
		if (!pendingCapture?.controllerTabId || !pendingCapture?.controllerWindowId) {
			throw new Error("No OpenCut capture request is waiting in this window.");
		}
		if (pendingCapture.controllerTabId === activeTab.id) {
			throw new Error("Switch to the tab you want to capture, then reopen the extension.");
		}

		const streamId = await chrome.tabCapture.getMediaStreamId({
			targetTabId: activeTab.id,
			consumerTabId: pendingCapture.controllerTabId,
		});

		const startResponse = await sendRuntimeMessage("tab-capture-start-target", {
			controllerTabId: pendingCapture.controllerTabId,
			controllerWindowId: pendingCapture.controllerWindowId,
			targetTabId: activeTab.id,
			shouldHideNativeCursor: Boolean(pendingCapture.shouldHideNativeCursor),
			showHelperCursor: Boolean(pendingCapture.showHelperCursor),
		});
		if (!startResponse?.ok) {
			throw new Error(startResponse?.error || "Failed to start tracking on the selected tab.");
		}

		await chrome.tabs.sendMessage(pendingCapture.controllerTabId, {
			namespace: MESSAGE_NAMESPACE,
			type: "tab-capture-stream-ready",
			payload: {
				streamId,
				targetTabId: activeTab.id,
			},
		});

		setStatus("This tab was connected to OpenCut.");
		window.close();
	} catch (error) {
		setStatus(
			error instanceof Error ? error.message : "Failed to capture this tab for OpenCut.",
			true,
		);
	}
}

async function startTracking() {
	try {
		await sendMessage("start");
		setStatus("Tracking started on the current tab.");
		await refreshStatus();
	} catch (error) {
		setStatus(
			error instanceof Error ? error.message : "Failed to start tracking.",
			true,
		);
	}
}

async function stopTracking() {
	try {
		await sendMessage("stop");
		setStatus("Tracking stopped. You can export the JSON file now.");
		await refreshStatus();
	} catch (error) {
		setStatus(
			error instanceof Error ? error.message : "Failed to stop tracking.",
			true,
		);
	}
}

async function exportTracking() {
	try {
		const response = await sendMessage("export");
		if (!response?.ok || !response.payload) {
			throw new Error(response?.error || "No tracking data is available");
		}

		const blob = new Blob([JSON.stringify(response.payload, null, 2)], {
			type: "application/json",
		});
		const url = URL.createObjectURL(blob);
		await chrome.downloads.download({
			url,
			filename: buildFilename(response.payload.page?.title),
			saveAs: true,
		});
		setTimeout(() => URL.revokeObjectURL(url), 5000);
		setStatus(
			`${response.payload.cursorTracking?.samples?.length || 0} cursor samples exported.`,
		);
	} catch (error) {
		setStatus(
			error instanceof Error ? error.message : "Failed to export tracking.",
			true,
		);
	}
}

elements.captureTab.addEventListener("click", () => {
	void captureTabForOpenCut();
});

elements.start.addEventListener("click", () => {
	void startTracking();
});

elements.stop.addEventListener("click", () => {
	void stopTracking();
});

elements.export.addEventListener("click", () => {
	void exportTracking();
});

void refreshStatus();
